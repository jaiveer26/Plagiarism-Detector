from django.shortcuts import render
from django.contrib.auth.decorators import login_required
from django.db import models

import docx2txt
import difflib
import nltk
import PyPDF2
#class UploadFile(models.Model):
    #uploadfile = models.FileField(upload_to='toProcess/')
# Create your views here.


def login(request):
    return render(request, 'users/login.html')


def home(request):
    return render(request, 'dejavu/home.html')

# def home(request):
#	context={
#		'copy' : copy
#	}
#	return render(request,'dejavu/home.html',context)


def about(request):
    return render(request, 'dejavu/about.html')


def index(request):
    djtext1 = request.POST.get('t1', 'default')
    djtext2 = request.POST.get('t2', 'default')
    djtext3=" "
    djtext3=djtext1+djtext2
    
    if request.method == 'POST' and djtext3=="":
        bfile1 = request.FILES['f1']
        bfile2 = request.FILES['f2']
        bfile1.save()
        bfile2.save()
        ext1=" "
        ext2=" "
        ext1=bfile1.name()
        ext2=bfile2.name()
        x1=docx2txt.process(bfile1)
        a=PyPDF2.PdfFileReader(bfile2)
        z=" "
        num=a.getNumPages()
        for i in range(1,num):
            z+=a.getPage(i).extractText()
        params={'text1': x1, 'text2': z}
        return render(request, 'result.html', params)
    else:
        seq = difflib.SequenceMatcher(None, djtext1, djtext2)
        d = seq.ratio()*100
        x = ""
        x = str(d)
        params = {'text1': djtext1, 'text2': x}
        return render(request, 'result.html', params)
    
   

    #

